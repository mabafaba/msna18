each csv contains a spreadsheet with the most common answer to the hypothetical question contained in a column. 
Each spreadsheet contains a different number of most common answers so each one will be auto-symbolized differently
according to the script. I decided 7 classes was the maximum for this type of chloropleth. Therefore, Q7 which has 8 unique
most common answers will display an error message.